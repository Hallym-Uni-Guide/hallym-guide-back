const express = require("express");
const cors = require("cors");

const scheduleRouter = require("./calender_routes/scheduleRouter");
const timetableRouter = require("./calender_routes/timetableRouter");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api/schedules", scheduleRouter);
app.use("/api/timetable", timetableRouter);

app.get("/", (req, res) => {
    res.send("씨애랑 백엔드 서버 실행 중");
});

app.listen(PORT, () => {
    console.log(`서버 실행: http://localhost:${PORT}`);
});