const express = require("express");

const router = express.Router();

// 실제 데이터는 나중에 연결
const searchData = [];

const allowedTypes = [
    "all",
    "notice",
    "schoolLife",
    "campus",
    "schedule"
];

router.get("/", (req, res) => {
    const keyword = String(req.query.keyword || "")
        .trim()
        .toLowerCase();

    const requestedType =
        String(req.query.type || "all").trim();

    const type = allowedTypes.includes(requestedType)
        ? requestedType
        : "all";

    if (!keyword) {
        return res.status(400).json({
            success: false,
            message: "검색어를 입력해주세요."
        });
    }

    const keywordResults = searchData.filter((item) => {
        const searchableText = [
            item.title,
            item.content,
            item.category
        ]
            .map((value) => String(value || "").toLowerCase())
            .join(" ");

        return searchableText.includes(keyword);
    });

    const filterCounts = {
        all: keywordResults.length,
        notice: 0,
        schoolLife: 0,
        campus: 0,
        schedule: 0
    };

    keywordResults.forEach((item) => {
        if (filterCounts[item.type] !== undefined) {
            filterCounts[item.type]++;
        }
    });

    const filteredResults =
        type === "all"
            ? keywordResults
            : keywordResults.filter(
                  (item) => item.type === type
              );

    return res.json({
        success: true,
        keyword: req.query.keyword.trim(),
        selectedType: type,
        totalCount: filteredResults.length,
        filterCounts,
        results: filteredResults
    });
});

module.exports = router;