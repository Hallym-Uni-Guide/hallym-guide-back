const API_URL = "http://localhost:3000";

const resultSearchForm =
    document.getElementById("resultSearchForm");

const resultSearchInput =
    document.getElementById("resultSearchInput");

const keywordText =
    document.getElementById("keywordText");

const resultCount =
    document.getElementById("resultCount");

const resultList =
    document.getElementById("resultList");

const filterButtons =
    document.querySelectorAll(".filter-button");

const urlParams = new URLSearchParams(window.location.search);

let currentKeyword = urlParams.get("keyword") || "";
let currentType = urlParams.get("type") || "all";

resultSearchInput.value = currentKeyword;

resultSearchForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const keyword = resultSearchInput.value.trim();

    if (!keyword) {
        alert("검색어를 입력해주세요.");
        return;
    }

    currentKeyword = keyword;
    currentType = "all";

    updateAddress();
    loadSearchResults();
});

filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
        currentType = button.dataset.type;

        updateAddress();
        loadSearchResults();
    });
});

function updateAddress() {
    const params = new URLSearchParams();

    params.set("keyword", currentKeyword);
    params.set("type", currentType);

    history.pushState(
        {},
        "",
        `search.html?${params.toString()}`
    );
}

async function loadSearchResults() {
    if (!currentKeyword) {
        keywordText.textContent = "";
        resultCount.textContent = "0";

        resultList.innerHTML = `
            <div class="empty-message">
                검색어를 입력해주세요.
            </div>
        `;

        return;
    }

    try {
        const response = await fetch(
            `${API_URL}/search` +
            `?keyword=${encodeURIComponent(currentKeyword)}` +
            `&type=${encodeURIComponent(currentType)}`
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.message || "검색 중 오류가 발생했습니다."
            );
        }

        renderSearchResults(data);
    } catch (error) {
        console.error(error);

        keywordText.textContent = currentKeyword;
        resultCount.textContent = "0";

        resultList.innerHTML = `
            <div class="empty-message">
                검색 결과를 불러오지 못했습니다.
            </div>
        `;
    }
}

function renderSearchResults(data) {
    keywordText.textContent = data.keyword;
    resultCount.textContent = data.totalCount;

    document.getElementById("allCount").textContent =
        data.filterCounts.all;

    document.getElementById("noticeCount").textContent =
        data.filterCounts.notice;

    document.getElementById("schoolLifeCount").textContent =
        data.filterCounts.schoolLife;

    document.getElementById("campusCount").textContent =
        data.filterCounts.campus;

    document.getElementById("scheduleCount").textContent =
        data.filterCounts.schedule;

    filterButtons.forEach((button) => {
        const isSelected =
            button.dataset.type === data.selectedType;

        button.classList.toggle("active", isSelected);
    });

    if (data.results.length === 0) {
        resultList.innerHTML = `
            <div class="empty-message">
                검색 결과가 없습니다.
            </div>
        `;

        return;
    }

    resultList.innerHTML = data.results
        .map((item) => {
            return `
                <article class="result-item">
                    <div class="result-category">
                        ${escapeHtml(item.category)}
                    </div>

                    <h2 class="result-title">
                        <a href="${escapeHtml(item.url)}">
                            ${escapeHtml(item.title)}
                        </a>
                    </h2>

                    <p>
                        ${escapeHtml(item.content)}
                    </p>
                </article>
            `;
        })
        .join("");
}

function escapeHtml(value) {
    return String(value || "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

loadSearchResults();