const express = require("express");
const cors = require("cors");

const searchRouter = require("./searchRouter");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

app.use("/search", searchRouter);

app.listen(PORT, () => {
    console.log(`서버 실행: http://localhost:${PORT}`);
});