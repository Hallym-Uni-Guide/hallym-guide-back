//npm install express cors axios cheerio

const axios = require("axios");
const cheerio = require("cheerio");

const NOTICE_URL =
    "https://www.hallym.ac.kr/hallym/1136/subview.do";

/**
 * 한림대학교 일반공지 크롤링
 *
 * @param {number} limit 가져올 공지 개수
 * @returns {Promise<Array>}
 */
async function getNotices(limit = 10) {
    try {
        const response = await axios.get(NOTICE_URL, {
            headers: {
                "User-Agent":
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                    "AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/150.0.0.0 Safari/537.36",

                "Accept":
                    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",

                "Accept-Language": "ko-KR,ko;q=0.9",
            },

            timeout: 10000,

            // 학교 서버가 리다이렉트할 경우 허용
            maxRedirects: 5,
        });

        const $ = cheerio.load(response.data);
        const notices = [];

        /*
         * K2Web 게시판의 테이블 행 조회
         */
        $("table tbody tr").each((index, element) => {
            if (notices.length >= limit) {
                return false;
            }

            const row = $(element);
            const columns = row.find("td");

            /*
             * 게시글이 아닌 행은 제외
             */
            if (columns.length < 4) {
                return;
            }

            /*
             * 상세보기 링크를 가진 제목 요소 조회
             */
            const titleElement = row.find(
                'a[href*="artclView.do"]'
            ).first();

            const href = titleElement.attr("href");

            /*
             * 새글 이미지나 분류 문구가 제목에 포함될 수 있으므로
             * 불필요한 요소를 복사본에서 제거
             */
            const titleClone = titleElement.clone();

            titleClone.find(
                "img, span.new, span.category, .new"
            ).remove();

            const title = titleClone
                .text()
                .replace(/\s+/g, " ")
                .trim();

            if (!title || !href) {
                return;
            }

            /*
             * 일반적인 게시판 순서:
             * 번호 / 제목 / 작성자 / 첨부 / 작성일 / 조회
             */
            const number = columns.eq(0).text().trim();

            const writer =
                row.find(".td-write").text().trim() ||
                columns.eq(2).text().trim();

            const date =
                row.find(".td-date").text().trim() ||
                findDate(columns);

            const views =
                row.find(".td-access").text().trim() ||
                columns.last().text().trim();

            const link = href.startsWith("http")
                ? href
                : new URL(href, NOTICE_URL).href;

            notices.push({
                id: number || index + 1,
                title,
                writer,
                date,
                views,
                link,
            });
        });

        if (notices.length === 0) {
            throw new Error(
                "공지사항을 찾지 못했습니다. 학교 홈페이지의 HTML 구조가 변경되었을 수 있습니다."
            );
        }

        return notices;
    } catch (error) {
        console.error(
            "공지사항 크롤링 실패:",
            error.response?.status || "",
            error.message
        );

        throw new Error(
            "학교 공지사항을 가져오지 못했습니다."
        );
    }
}

/**
 * 여러 td 중 YYYY-MM-DD 형식의 날짜를 찾는다.
 *
 * @param {*} columns Cheerio td 요소 목록
 * @returns {string}
 */
function findDate(columns) {
    let date = "";

    columns.each((index, element) => {
        const text = cheerio
            .load(element)
            .root()
            .text()
            .trim();

        if (/^\d{4}[-./]\d{2}[-./]\d{2}$/.test(text)) {
            date = text;
            return false;
        }
    });

    return date;
}

module.exports = {
    getNotices,
};