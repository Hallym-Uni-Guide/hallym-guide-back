const express = require("express");
const cors = require("cors");
const { getNotices } = require("./noticeCrawler");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
    res.send("씨애랑 백엔드 서버 실행 중");
});

/**
 * GET /api/notices
 * 학교 공지사항 조회
 *
 * 예시:
 * /api/notices
 * /api/notices?limit=5
 */
app.get("/api/notices", async (req, res) => {
    try {
        const requestedLimit = Number(req.query.limit);
        const limit =
            Number.isInteger(requestedLimit) &&
            requestedLimit > 0 &&
            requestedLimit <= 30
                ? requestedLimit
                : 10;

        const notices = await getNotices(limit);

        res.status(200).json({
            success: true,
            count: notices.length,
            notices,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
});

app.listen(PORT, () => {
    console.log(`서버 실행: http://localhost:${PORT}`);
});